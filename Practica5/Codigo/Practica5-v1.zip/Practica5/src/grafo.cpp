#include "grafo.hpp"

Grafo::iterator Grafo::begin(){
    Grafo::iterator i;
    i.it = nodos.begin();
    return i;
};
Grafo::iterator Grafo::end(){
    Grafo::iterator i;
    i.it = nodos.end();
    return i;
};
Grafo::const_iterator Grafo::cbegin() const{
    const_iterator i;
    i.it = nodos.cbegin();
    return i;
};
Grafo::const_iterator Grafo::cend() const{
    Grafo::const_iterator i;
    i.it = nodos.cend();
    return i;
};

Grafo& Grafo::operator+(const Nodo &n){
    Grafo::const_iterator it = this->cbegin();
    bool encontrado = false;
    while ( it != this->cend() && !encontrado){
        if (n == (*it))
            encontrado=true;
        else
            ++it;
    }

    if (!encontrado)
    {
        this->dimension++; 
        nodos.push_back(n);
    }     
    return *this;
};

const Nodo& Grafo::operator[](int id) const{
    Grafo::const_iterator cit = cbegin();
    int id_actual = -1;
    while( id != id_actual && cit != cend())
    {
        if ( id == (*cit).getId() )
            id_actual = id;
        else
            ++cit;
    }

    if (id_actual != -1)
        return (*cit);
    else
    {
        static Nodo n(-1,-1,-1);
        return n;
    }
};

Grafo& Grafo::operator=(const Grafo &g) {
    this->dimension = g.dimension;
    this->nodos = g.nodos;
    this->matrizAdyacencia = g.matrizAdyacencia;

    return *this;
};

void Grafo::rellenarMatriz() {
    for(int i=0; i<this->dimension; i++) {
        for(int j=i; j<this->dimension; j++) 
            this->matrizAdyacencia[i][j] = this->matrizAdyacencia[j][i] = this->nodos[i].distancia(this->nodos[j]);
    }
}

void Grafo::rellenarVector()
{
    double menor, segundo_menor;
    for ( Grafo::iterator it = begin(); it != end(); ++it)
    {
        if ( (*it).getId() == 1 ) //revisión
        {
            menor = matrizAdyacencia[ (*it).getId() -1 ][1];
            segundo_menor = matrizAdyacencia[ (*it).getId() -1 ][2];
        }
        else
        {
            menor = matrizAdyacencia[ (*it).getId() -1 ][0];
            if ( (*it).getId() == getDimension())
                segundo_menor = matrizAdyacencia[ (*it).getId() -1 ][1];
            else
                segundo_menor = matrizAdyacencia[ (*it).getId() -1 ][getDimension()-1];
        }
        
        for (Grafo::iterator it_2 = begin(); it_2 != end(); ++it_2)
        {
            if(it_2 != it)  {
                double distancia;
                distancia = matrizAdyacencia[ (*it).getId() -1 ][ (*it_2).getId() -1 ];
                if (distancia < menor)
                {
                    segundo_menor = menor;
                    menor = distancia;
                }
                else if(distancia < segundo_menor)
                    segundo_menor = distancia;
            }
        }
        distanciasEstimadas.push_back((menor+segundo_menor)/2);
    }
    
}

double Grafo::estimacion(vector<int> caminoLocal) {
    double cotaLocal=0;
    
    //crear candidatos y rellenarlos
    vector<int> candidatos;
    for (unsigned int i = 0; i < nodos.size(); i++)
        candidatos.push_back(i+1);

    vector<int>::iterator it = candidatos.begin();
    double valor_entrada, valor_salida;
    
    if(caminoLocal.size() == 1) {
        double posible_entrada = matrizAdyacencia[0][1]; // distancia de A(siempre 0) con C (el segundo elemento de camino local)
        vector<int>::iterator entrada;
        ++it;++it; 
        for (; it != candidatos.end(); ++it)
        {
            if ( matrizAdyacencia[0][(*it)-1] < posible_entrada ) {
                posible_entrada = matrizAdyacencia[0][(*it)-1]; 
                entrada = it;
            }
        }

        double posible_salida = matrizAdyacencia[0][2];
        it = candidatos.begin();
        ++it;++it;++it;
        for (; it != candidatos.end(); ++it)
        {
            if ( matrizAdyacencia[0][(*it)-1] < posible_entrada && it != entrada)
                posible_salida = matrizAdyacencia[0][(*it)-1];
        }

        valor_entrada = posible_entrada;
        valor_salida = posible_salida;
        cotaLocal += (valor_entrada+valor_salida)/2;
    }
    else {
        it = candidatos.begin();

        double posible_entrada;
        if (caminoLocal.size() < 3 && caminoLocal[1] != candidatos[1])
            posible_entrada = matrizAdyacencia[0][ candidatos[1] - 1 ];              //distancia de A con el primer candidato si el tamaño es 2 para no coger B
        else if (caminoLocal.size() < 3)
            posible_entrada = matrizAdyacencia[0][ candidatos[2] -1 ];              //distancia de A con el segundo candidato que no es A, si el segundo de candidatos es igual B
        else
            posible_entrada = matrizAdyacencia[0][ caminoLocal[2] - 1];          // distancia de A(siempre 0) con C (el segundo elemento de camino local)
        
        ++it;++it;++it; // restas las iteraciones de A consigo mismo, A con el siguiente (ya que es valor de salida) y A con C porque es el valor de posible entrada 
        
        for (; it != candidatos.end(); ++it)
        {
            if ( matrizAdyacencia[0][(*it)-1] < posible_entrada )
                posible_entrada = matrizAdyacencia[0][(*it)-1];      
        }
        
        valor_entrada = posible_entrada;
        valor_salida = matrizAdyacencia[0][ caminoLocal[1] - 1]; //distancia de A con B
        cotaLocal += (valor_entrada+valor_salida)/2;

        it = caminoLocal.begin() + 1;
        vector<int>::iterator puntero; //valor del siguiente o anterior nodo de la secuencia

        for (; it != caminoLocal.end()-1 && caminoLocal.size()>2; ++it)
        {
            puntero = it; 
            valor_entrada = matrizAdyacencia[*(it)-1][*(puntero-1)-1];
            valor_salida = matrizAdyacencia[*(it)-1][*(puntero+1)-1];
            cotaLocal += (valor_entrada+valor_salida)/2;
        }

        valor_entrada = matrizAdyacencia[*(it-1)-1][*(it)-1];
        int indice_ultimo = *(it);
        int indice_anterior = *(it-1);
        double posible_salida = matrizAdyacencia[indice_ultimo - 1][ caminoLocal[0] - 1 ]; // distancia del último valor de la secuenciaLocal con A
        it = candidatos.begin();
        for (; it != candidatos.end(); ++it)
        {
            if ( matrizAdyacencia[indice_ultimo - 1][(*it)-1] < posible_salida && *(it) != indice_ultimo && *(it) != indice_anterior)
                posible_salida = matrizAdyacencia[indice_ultimo - 1][(*it)-1];   
        }

        valor_salida = posible_salida;  
        cotaLocal += (valor_entrada+valor_salida)/2;
    }
    // Se borran los candidatos que están en camino local
    it = candidatos.begin();
    for (vector<int>::iterator i = caminoLocal.begin();  i != caminoLocal.end(); i++)
    {
        bool encontrado = false;
        while ( it != candidatos.end() && !encontrado)
        {
            if( *(i) == *(it) )
            {
                candidatos.erase(it);
                encontrado = true;
            }
            else
                ++it;   
        }
    }

    for (it = candidatos.begin(); it != candidatos.end(); ++it)
        cotaLocal += distanciasEstimadas[*(it) - 1];
    
    return cotaLocal;
}

pair<double, list<int>> Grafo::backTracking(int indice, list<int> conjunto) 
{
    double cota_global = __DBL_MAX__;
    

    list<int> aux = conjunto, vacia;
    list<int> camino;
    
    pair<double, list<int>> min, min_aux;
    min = make_pair(cota_global, vacia);
    camino.push_back(indice);

    if (conjunto.size() == 0)
    {
        return make_pair(matrizAdyacencia[indice-1][0],camino);
    }
    else
    {
        list<int> camino_siguiente = camino;
        int indice_siguiente = aux.front();
        
        list<int>::iterator it = aux.begin();

        for (; it != aux.end(); ++it)
        {
            indice_siguiente = (*it);
            it = aux.erase(it);

            list<int> camino_aux = camino;

            vector<int> caminoLocal;
            for (list<int>::iterator it = camino.begin(); it != camino.end(); ++it)
                caminoLocal.push_back((*it));
             
            

            if(estimacion(caminoLocal) < min.first) {
                pair<double, list<int>> resultadoHijo = backTracking(indice_siguiente,aux);
                camino_aux.splice(camino_aux.end(), resultadoHijo.second);
                min_aux = make_pair(matrizAdyacencia[indice-1][indice_siguiente-1] + resultadoHijo.first, camino_aux);
                aux.insert(it,indice_siguiente);

                if(min_aux.first < min.first) {
                    min = min_aux;
                }
            }         
        }

        return min;
    }
}


pair<double, list<int>> Grafo::distanciaConjunto(int indice, list<int> conjunto) {
    list<int> aux = conjunto;
    list<int> camino;
    
    pair<double, list<int>> min, min_aux;
    camino.push_back(indice);

    if (conjunto.size() == 0)
    {
        return make_pair(matrizAdyacencia[indice-1][0],camino);
    }
    else
    {
    
        list<int> camino_siguiente = camino;
        int indice_siguiente = aux.front();
        aux.pop_front();
        pair<double, list<int>> resultadoHijo = distanciaConjunto(indice_siguiente,aux);
        camino_siguiente.splice(camino_siguiente.end(), resultadoHijo.second);
        min = make_pair(matrizAdyacencia[indice-1][indice_siguiente-1] + resultadoHijo.first, camino_siguiente);
        aux.push_front(indice_siguiente);

        list<int>::iterator it = aux.begin();
        ++it;

        for (; it != aux.end(); ++it)
        {
            indice_siguiente = (*it);
            it = aux.erase(it);

           
            list<int> camino_aux = camino;

            pair<double, list<int>> resultadoHijo = distanciaConjunto(indice_siguiente,aux);
            camino_aux.splice(camino_aux.end(), resultadoHijo.second);
            min_aux = make_pair(matrizAdyacencia[indice-1][indice_siguiente-1] + resultadoHijo.first, camino_aux);
            aux.insert(it,indice_siguiente);
           
            if(min_aux.first < min.first) {
                min = min_aux;  
            }            
        }

        return min;
    }
}

ostream& operator<<(ostream& os, Grafo grafo) {
    for (Grafo::const_iterator cit = grafo.cbegin(); cit != grafo.cend(); ++cit)
        cout << *cit << "\n";

    cout << endl;
    return os;
}

istream& operator>>(istream& is, Grafo& grafo) {
    string linea;
    getline(is, linea);
    getline(is, linea);
    getline(is, linea);
    getline(is, linea);

    string aux;
    
    size_t posDimension = linea.find(":");
    posDimension++;
    aux = linea.substr(posDimension);
    
    grafo.dimension = stoi(aux);

    grafo.nodos = vector<Nodo>(grafo.dimension);
    grafo.matrizAdyacencia = vector<vector<double>> (grafo.dimension, std::vector<double>(grafo.dimension));

    getline(is, linea);
    getline(is, linea);
    getline(is, linea);

    for(int i=0; i<grafo.dimension; i++) {
        Nodo nodoAux;
        is >> nodoAux;
        grafo.nodos[i] = nodoAux;
    }

    grafo.rellenarMatriz();
    grafo.rellenarVector();
    
    return is;
}
