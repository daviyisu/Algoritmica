#include "camino.hpp"


void Camino::calcularDistancia()
{
    double distancia = 0.0;
    size_t i = 0;

    for (; i < size() - 1; i++)
    {
        distancia += matrizAdyacencia[recorrido[i] - 1][recorrido[i + 1] - 1];
    }

    this->distancia = distancia;
}

Camino::Camino(vector<int> recorrido, vector<vector<double>> matriz)
{
    this->recorrido = recorrido;
    this->matrizAdyacencia = matriz;
    calcularDistancia();
    calcularEstimacion();
}

Camino::Camino()
{
    this->distancia = 0;
    this->estimacion = 0;
}

bool Camino::satisfacible() const
{
    bool satisface = true;
    for (size_t i = 0; i < recorrido.size() && satisface; i++)
    {
        for (size_t j = 0; j < recorrido.size() && satisface; j++)
        {
            if (recorrido[i] == recorrido[j] && i != j)
                satisface = false;
        }
    }

    return satisface;
}

void Camino::push_back(int nuevo)
{
    recorrido.push_back(nuevo);
    calcularDistancia();
    calcularEstimacion();
}

void Camino::clear()
{
    recorrido.clear();
    distancia = 0;
    estimacion = 0;
}

const int & Camino::operator[](int i) const {
    return recorrido[i];
}

int & Camino::operator[](int i) {
    return recorrido[i];
}

void Camino::calcularEstimacion()
{
    double cota = 0.0;
    vector<int> candidatos;
    double d_min = __DBL_MAX__;

    for (size_t i = 0; i < matrizAdyacencia.size(); i++)
        candidatos.push_back(i + 1);

    if (size() == 1)
    {
        for (size_t i = 0; i < candidatos.size(); i++)
        {
            int id_seleccionada = candidatos[i];
            for (size_t j = 0; j < candidatos.size(); j++)
            {
                if (d_min > matrizAdyacencia[id_seleccionada - 1][candidatos[j] - 1] && i != j)
                {
                    d_min = matrizAdyacencia[id_seleccionada - 1][candidatos[j] - 1];
                }
            }
            cota += d_min;
            d_min = __DBL_MAX__;
        }
    }
    else
    {
        //Borramos los elementos de candidatos que estén en caminoLocal
        vector<int>::iterator it = candidatos.begin();
        for (vector<int>::iterator i = recorrido.begin(); i != recorrido.end(); i++)
        {
            bool encontrado = false;
            while (it != candidatos.end() && !encontrado)
            {
                if (*(i) == *(it))
                {
                    candidatos.erase(it);
                    encontrado = true;
                }
                else
                    ++it;
            }
        }

        double valor;
        for (size_t i=0; i < size() - 1; i++)
        {
            valor = matrizAdyacencia[ recorrido[i]-1 ][ recorrido[i+1] - 1 ];
            cota += valor;
        }

        for (size_t i=0; i < size(); i++)
        {
            for (size_t j = 0; j < size(); j++)
            {
                if (d_min > matrizAdyacencia[ recorrido[i] - 1 ][ recorrido[j]-1 ])
                    d_min = matrizAdyacencia[ recorrido[i] - 1][ recorrido[j] -1 ];
            }
            
            for (size_t j = 0; j < candidatos.size(); ++j)
            {
                if (d_min > matrizAdyacencia[ recorrido[i] - 1][ recorrido[j] -1 ] && i != j)
                    d_min = matrizAdyacencia[ recorrido[i] - 1][ recorrido[j] -1 ];
            }

            cota += d_min;
            d_min = __DBL_MAX__;
        }
    }
    estimacion = cota;
}

Camino& Camino::operator=(Camino b){
    this->distancia = b.distancia;
    this->estimacion = b.estimacion;
    this->matrizAdyacencia = b.matrizAdyacencia;
    this->recorrido = b.recorrido;
    return *this;
}