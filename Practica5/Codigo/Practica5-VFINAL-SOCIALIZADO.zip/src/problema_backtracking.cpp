
#include <iostream>
#include <fstream>
#include <list>
#include <ctime>
#include "grafo.hpp"

using namespace std;

void mostrarLista(const Grafo& g,const list<int> &lista, string ficheroEntrada, string modo, double tiempo, double dist){
    
    size_t principio_frase = ficheroEntrada.find_last_of("/");
    size_t final_frase = ficheroEntrada.find_last_of(".");
    size_t tam_frase = final_frase - principio_frase;

    string ficheroSalida = ficheroEntrada.substr(principio_frase+1, tam_frase-1);
    ficheroSalida += "-with-" + modo + ".tsp";

    ofstream salida("./data/" + ficheroSalida);

    salida << "NAME: " + ficheroSalida << "\n";
    salida << "TYPE: TSP\n";
    salida << "COMMENT: Elaborado con técnica "+modo+"\n";
    salida << "DIMENSION: " << lista.size() << "\n"; 
    salida << "EDGE_WEIGHT_TYPE: GEO\n";
    salida << "DISPLAY_DATA_TYPE: COORD_DISPLAY\n";
    salida << "NODE_COORD_SECTION\n";
    salida << "TIEMPO TARDADO: "<< tiempo << "\n";
    salida << "DISTANCIA: " << dist << "\n";

    list<int>::const_iterator it = lista.cbegin();
    for (;it != lista.cend(); ++it)
    {
        salida << g[(*it)]<<"\n";   
    }
         
    salida.close();
};

int main(int argc, char** argv){
    if (argc != 2)
    {
        cout<<"Escriba el nombre del fichero a leer \n";
        exit(-1);
    }
    
    clock_t t_antes, t_despues;
    double tiempo;

    string filename = argv[1];
    string modo = "Backtracking";
    
    ifstream fichero;
    fichero.open(filename);

    Grafo g;
    fichero >> g;
    

    list<int> resultado;
    list<int> conjunto;

    for (int i = 1; i < g.getDimension(); i++)
        conjunto.push_back(i+1);
    
    list<int>::iterator it;
    t_antes = clock();
    pair<double, list<int>> result = g.backTracking(1,conjunto);
    t_despues = clock();
    tiempo = (double) (t_despues - t_antes) / CLOCKS_PER_SEC;
    
    mostrarLista(g, result.second, filename, modo, tiempo, result.first);

    fichero.close();
     
    return(0);
}
