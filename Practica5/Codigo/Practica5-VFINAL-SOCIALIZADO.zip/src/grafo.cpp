#include "grafo.hpp"

Grafo::iterator Grafo::begin(){
    Grafo::iterator i;
    i.it = nodos.begin();
    return i;
};
Grafo::iterator Grafo::end(){
    Grafo::iterator i;
    i.it = nodos.end();
    return i;
};
Grafo::const_iterator Grafo::cbegin() const{
    const_iterator i;
    i.it = nodos.cbegin();
    return i;
};
Grafo::const_iterator Grafo::cend() const{
    Grafo::const_iterator i;
    i.it = nodos.cend();
    return i;
};

Grafo& Grafo::operator+(const Nodo &n){
    Grafo::const_iterator it = this->cbegin();
    bool encontrado = false;
    while ( it != this->cend() && !encontrado){
        if (n == (*it))
            encontrado=true;
        else
            ++it;
    }

    if (!encontrado)
    {
        this->dimension++; 
        nodos.push_back(n);
    }     
    return *this;
};

const Nodo& Grafo::operator[](int id) const{
    Grafo::const_iterator cit = cbegin();
    int id_actual = -1;
    while( id != id_actual && cit != cend())
    {
        if ( id == (*cit).getId() )
            id_actual = id;
        else
            ++cit;
    }

    if (id_actual != -1)
        return (*cit);
    else
    {
        static Nodo n(-1,-1,-1);
        return n;
    }
};

Grafo& Grafo::operator=(const Grafo &g) {
    this->dimension = g.dimension;
    this->nodos = g.nodos;
    this->matrizAdyacencia = g.matrizAdyacencia;

    return *this;
};

void Grafo::rellenarMatriz() {
    for(unsigned int i=0; i<this->dimension; i++) {
        for(unsigned int j=i; j<this->dimension; j++) 
            this->matrizAdyacencia[i][j] = this->matrizAdyacencia[j][i] = this->nodos[i].distancia(this->nodos[j]);
    }
}

double Grafo::cercania(list<int>& result) {
    list<int> candidatos;
    double distancia_a_devolver = 0;
    for(unsigned i=0; i<dimension; i++)
        candidatos.push_back(i+1);

    result.push_back(candidatos.front());
    candidatos.pop_front();

    list<int>::iterator it_candidatos;
    list<int>::iterator it_resultado = result.begin();
    double dist_min;
    list<int>::iterator menor_candidato;

    while ( !candidatos.empty() )
    {
        it_candidatos = candidatos.begin();
        dist_min = matrizAdyacencia[(*it_resultado)-1][(*it_candidatos)-1];
        menor_candidato = it_candidatos;

        for(; it_candidatos != candidatos.end(); ++it_candidatos){
            if(dist_min > matrizAdyacencia[(*it_resultado)-1][(*it_candidatos)-1])
            {
                dist_min = matrizAdyacencia[(*it_resultado)-1][(*it_candidatos)-1];
                menor_candidato = it_candidatos;
            }
        }

        result.push_back( (*menor_candidato) );
        candidatos.erase( menor_candidato ); 
       
        ++it_resultado;
        distancia_a_devolver += dist_min;
    }
    cota_global = distancia_a_devolver;
    return distancia_a_devolver;
};

// Esto es el Branch and Bound
struct comparaEstimacion
{
    bool operator()(Camino a, Camino b){        
        return  a.getEstimacion() > b.getEstimacion();
    }
};

Camino Grafo::branchAndBound(Camino caminoLocal) 
{
    if (caminoLocal.size() == dimension ) {                        //Caso base
        cota_global = caminoLocal.getEstimacion();
        return caminoLocal;
    }
    else
    {
        priority_queue<Camino, vector<Camino>, comparaEstimacion> cola_p;
        unsigned int i,j;
        vector<Camino> conjuntoCaminos;
        vector<int> vacio;
        Camino caminoExpandido(vacio, getMatriz());

        for(i=0; i<dimension; i++) {              //Añadimos todos los caminos expandidos al conjunto
            for(j=0; j<caminoLocal.size(); j++)
                caminoExpandido.push_back(caminoLocal[j]);
                
            caminoExpandido.push_back(nodos[i].getId());
            conjuntoCaminos.push_back(caminoExpandido);
            caminoExpandido.clear();
        }
        
        for(vector<Camino>::iterator it=conjuntoCaminos.begin(); it != conjuntoCaminos.end();) { //Borra los caminos no satisfacibles
            if(!it->satisfacible()) {
                conjuntoCaminos.erase(it);
            }else {
                ++it;
            }
        }

        for(i=0; i<conjuntoCaminos.size(); i++) {
            cola_p.push(conjuntoCaminos[i]);
            nodos_expandidos++;
        }

        tamanio_cola += cola_p.size();
        
        Camino mejorHijo = caminoLocal;
        while(!cola_p.empty()) {
            Camino caminoPrometedor = cola_p.top();

            if(tamanio_cola > maximo_cola)
                maximo_cola = tamanio_cola;

            cola_p.pop();                                      //Vamos repitiendo el proceso recursivamente con todos los caminos prometedores
            tamanio_cola--;
            if(caminoPrometedor.getEstimacion() <= cota_global)
            {
                Camino hijo = branchAndBound(caminoPrometedor);
                if(!hijo.es_nulo() && hijo.size() == dimension)
                    mejorHijo = hijo;       
            }
            else 
            {
                n_podas++;
            }
        }

        return mejorHijo;
    }   
}

pair<double, list<int>> Grafo::backTracking(int indice, list<int> conjunto) {
    list<int> aux = conjunto;
    list<int> camino;
    
    pair<double, list<int>> min, min_aux;
    camino.push_back(indice);

    if (conjunto.size() == 0)
    {
        return make_pair(0,camino);
    }
    else
    {
    
        list<int> camino_siguiente = camino;
        int indice_siguiente = aux.front();
        aux.pop_front();
        pair<double, list<int>> resultadoHijo = backTracking(indice_siguiente,aux);
        camino_siguiente.splice(camino_siguiente.end(), resultadoHijo.second);
        min = make_pair(matrizAdyacencia[indice-1][indice_siguiente-1] + resultadoHijo.first, camino_siguiente);
        aux.push_front(indice_siguiente);

        list<int>::iterator it = aux.begin();
        ++it;

        for (; it != aux.end(); ++it)
        {
            indice_siguiente = (*it);
            it = aux.erase(it);

            list<int> camino_aux = camino;

            pair<double, list<int>> resultadoHijo = backTracking(indice_siguiente,aux);
            camino_aux.splice(camino_aux.end(), resultadoHijo.second);
            min_aux = make_pair(matrizAdyacencia[indice-1][indice_siguiente-1] + resultadoHijo.first, camino_aux);
            aux.insert(it,indice_siguiente);
           
            if(min_aux.first < min.first) {
                min = min_aux;  
            }            
        }

        return min;
    }
}

ostream& operator<<(ostream& os, Grafo grafo) {
    for (Grafo::const_iterator cit = grafo.cbegin(); cit != grafo.cend(); ++cit)
        cout << *cit << "\n";

    cout << endl;
    return os;
}

istream& operator>>(istream& is, Grafo& grafo) {
    string linea;
    getline(is, linea);
    getline(is, linea);
    getline(is, linea);
    getline(is, linea);

    string aux;
    
    size_t posDimension = linea.find(":");
    posDimension++;
    aux = linea.substr(posDimension);
    
    grafo.dimension = stoi(aux);

    grafo.nodos = vector<Nodo>(grafo.dimension);
    grafo.matrizAdyacencia = vector<vector<double>> (grafo.dimension, std::vector<double>(grafo.dimension));

    getline(is, linea);
    getline(is, linea);
    getline(is, linea);

    for(unsigned int i=0; i<grafo.dimension; i++) {
        Nodo nodoAux;
        is >> nodoAux;
        grafo.nodos[i] = nodoAux;
    }


    grafo.rellenarMatriz();
    
    grafo.nodos_expandidos = 0;
    grafo.tamanio_cola = 0;
    grafo.n_podas = 0;
    grafo.maximo_cola = 0;
    
    return is;
}
