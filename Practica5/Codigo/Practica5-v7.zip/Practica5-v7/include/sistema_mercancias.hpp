#ifndef _SISTEMA_MERCANCIAS_HPP
#define _SISTEMA_MERCANCIAS_HPP

#include <iostream>
#include <vector>
#include <list>
#include <cmath>
#include <utility>
#include <map>
#include <stack>
#include <queue>
#include "nodo.hpp"

using namespace std;

class Sistema_mercancias{
    private:
        double dimension;
        vector<nodos> nodos;
        vector<int> puntos_venta; 
        vector<int> puntos_distribucion;
        double distancia;
    public:
        vector<int> getPuntosVenta() const { return puntos_venta; };
        vector<int> getPuntosDistribucion() const { return puntos_distribucion; };
        bool satisfacible(vector<int> v) const;
        vector<int> backTracking(vector<int> resultadoParcial);
        double calcularDistancia(vector<int> v);
};

#endif