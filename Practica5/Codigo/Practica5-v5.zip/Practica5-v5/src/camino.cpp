#include "camino.hpp"
#include <cfloat>

void Camino::calcularDistancia(vector<int> v)
{
    double distancia = 0.0;
    unsigned int i = 0;

    for (; i < v.size() - 1; i++)
    {
        distancia += g->getMatriz()[v[i] - 1][v[i + 1] - 1];
    }

    this->distancia = distancia;
}

Camino::Camino(vector<int> recorrido, Grafo *grafo)
{
    this->recorrido = recorrido;
    this->g = grafo;
    calcularDistancia(recorrido);
}

Camino::Camino()
{
    this->g = NULL;
    this->distancia = 0;
};

bool Camino::satisfacible() const
{
    bool satisface = true;
    for (int i = 0; i < recorrido.size() && satisface; i++)
    {
        for (int j = 0; j < recorrido.size() && satisface; j++)
        {
            if (recorrido[i] == recorrido[j] && i != j)
                satisface = false;
        }
    }

    return satisface;
}

void Camino::push_back(int nuevo)
{
    recorrido.push_back(nuevo);
    calcularDistancia(recorrido);
    estimacion = calcularEstimacion();
}

void Camino::clear()
{
    recorrido.clear();
    distancia = 0;
}

const int & Camino::operator[](int id) const {
    
}

double Camino::calcularEstimacion()
{
    double cota = 0.0;
    vector<int> candidatos;
    double d_min = __DBL_MAX__;

    for (unsigned int i = 0; i < g->getDimension(); i++)
        candidatos.push_back(i + 1);

    if (size() == 1)
    {
        for (unsigned int i = 0; i < candidatos.size(); i++)
        {
            int id_seleccionada = candidatos[i];
            for (unsigned int j = 0; j < candidatos.size(); j++)
            {
                if (d_min > g->getMatriz()[id_seleccionada - 1][candidatos[j] - 1] && i != j)
                {
                    d_min = g->getMatriz()[id_seleccionada - 1][candidatos[j] - 1];
                }
            }
            cota += d_min;
            d_min = __DBL_MAX__;
        }
    }
    else
    {
        //Borramos los elementos de candidatos que estén en caminoLocal
        vector<int>::iterator it = candidatos.begin();
        for (vector<int>::iterator i = recorrido.begin(); i != recorrido.end(); i++)
        {
            bool encontrado = false;
            while (it != candidatos.end() && !encontrado)
            {
                if (*(i) == *(it))
                {
                    candidatos.erase(it);
                    encontrado = true;
                }
                else
                    ++it;
            }
        }

        double valor;
        for (int i=0; i < size() - 1; i++)
        {
            valor = g->getMatriz()[ recorrido[i]-1 ][ recorrido[i+1] - 1 ];
            cota += valor;
        }

        for (int i=0; i < size(); i++)
        {
            for (int j = 0; j < size(); j++)
            {
                if (d_min > g->getMatriz()[ recorrido[i] - 1 ][ recorrido[j]-1 ])
                    d_min = g->getMatriz()[ recorrido[i] - 1][ recorrido[j] -1 ];
            }

            for (vector<int>::iterator j = candidatos.begin(); j != candidatos.end(); ++j)
            {
                if (d_min > g->getMatriz()[ (*it) - 1][*(j)-1] && it != j)
                    d_min = g->getMatriz()[ (*it) - 1][*(j)-1];
            }

            cota += d_min;
            d_min = __DBL_MAX__;
        }
    }
    estimacion = cota;
}
