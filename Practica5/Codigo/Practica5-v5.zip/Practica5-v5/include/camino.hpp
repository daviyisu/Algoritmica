#ifndef _CAMINO_HPP
#define _CAMINO_HPP

#include <iostream>
#include <vector>
#include <list>
#include <cmath>
#include <utility>
#include <map>
#include <stack>
#include <queue>
#include "grafo.hpp"
#include <cfloat>

using namespace std;

class Camino{
    private:
        vector<int> recorrido;
        Grafo* g;
        double distancia;
        double estimacion;
    
        void calcularDistancia(vector<int> v);

    public:

    Camino(vector<int> recorrido, Grafo* grafo);
    Camino();

    bool satisfacible() const;
    
    void push_back(int nuevo);

    void clear();
    const int & operator[](int id) const;
    
    double calcularEstimacion();

    double getEstimacion() { return estimacion};
    double getDistancia() { return distancia; };
    size_t size() { return recorrido.size(); }; 

};

#endif