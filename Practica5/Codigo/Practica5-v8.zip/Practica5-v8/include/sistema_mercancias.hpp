#ifndef _SISTEMAMERCANCIAS_HPP
#define _SISTEMAMERCANCIAS_HPP

#include <iostream>
#include <vector>
#include <list>
#include <cmath>
#include <utility>
#include <map>
#include <stack>
#include <queue>
#include "nodo.hpp"

using namespace std;

class SistemaMercancias{
    private:
        double dimension;
        vector<Nodo> nodos;
        vector<int> puntos_venta; 
        vector<int> puntos_distribucion;
        double distancia;
    public:
        vector<int> getPuntosVenta() const { return puntos_venta; };
        vector<int> getPuntosDistribucion() const { return puntos_distribucion; };
        Nodo getNodo( int indice) const { return nodos[indice]; };
        double getDimension() const { return dimension; };
        double getDistancia() const { return distancia; };

        bool satisfacible(vector<int> v) const;
        vector<int> backTracking(vector<int> resultadoParcial);
        double calcularDistancia(vector<int> v);

        friend istream & operator>>(istream &is, SistemaMercancias &sist);
};

#endif