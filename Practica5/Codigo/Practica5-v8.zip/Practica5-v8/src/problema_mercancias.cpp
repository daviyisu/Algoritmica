#include <vector>
#include <fstream>
#include <iostream>
#include "sistema_mercancias.hpp"

void mostrarVector(const vector<int> &v, SistemaMercancias sm , string ficheroSalida){
    
    ofstream salida("./data/" + ficheroSalida);

    salida << "SOLUCIÓN DE CAMINO MINIMO:\n";
    salida << "DIMENSION: " << sm.getDimension() << "\n";
    salida << "DISTANCIA: " << sm.getDistancia() << "\n"; 

    for (size_t i = 0; i<v.size() ; i++)
    {
        salida << sm.getNodo( (v[i]-1) ) <<"\n";   
    }
         
    salida.close();
};


int main( int argc, char **argv){
    if (argc != 2)
    {
        cout<<"Escriba el nombre del fichero a leer \n";
        exit(-1);
    }

    string filename = argv[1];
    ifstream fichero;
    fichero.open(filename);

    SistemaMercancias sm;
    fichero >> sm;

    vector<int> v, result;
    v.push_back(1);
    result = sm.backTracking(v);

    filename = filename + "_Backtracking";
    mostrarVector(result, sm, filename);

    fichero.close();
     
    return(0);
}