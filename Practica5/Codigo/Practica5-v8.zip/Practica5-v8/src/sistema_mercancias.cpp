#include "sistema_mercancias.hpp"


bool SistemaMercancias::satisfacible(vector<int> v) const
{
    bool satisface = true;
    for (size_t i = 0; i < v.size() && satisface; i++)
    {
        for (size_t j = 0; j < v.size() && satisface; j++)
        {
            if (v[i] == v[j] && i != j)
                satisface = false;
        }
    }

    return satisface;
}

double SistemaMercancias::calcularDistancia(vector<int> v){
    double result = 0;
    for (vector<int>::iterator it = v.begin(); it != v.end(); it+=2)
    {
        result += nodos[(*it)-1].distancia(nodos[(*it)-1]);
    }
    return result;
}

vector<int> SistemaMercancias::backTracking(vector<int> resultadoParcial)
{

    if (resultadoParcial.size() == dimension * 2) //Caso Base
    {
        return resultadoParcial;
    }
    else
    {
        vector<int> result;
        vector<vector<int>> todos_resultados;
        bool nivel_venta = resultadoParcial.size() % 2 == 0;
        vector<int> resultadoLocal = resultadoParcial;

        if (nivel_venta) //Generamos todos los resultados expandidos, si el nivel es par, añadimos los puntos de distribución
        {
            for (int i = 0; i < dimension; i++)
            {
                resultadoLocal.push_back(puntos_distribucion[i]);
                todos_resultados.push_back(resultadoLocal);
                resultadoLocal.pop_back();
            }
        }
        else //Si estamos en un nivel impar, le añadimos todos sus hijos que son puntos de venta
        {
            for (int i = 0; i < dimension; i++)
            {
                resultadoLocal.push_back(puntos_venta[i]);
                todos_resultados.push_back(resultadoLocal);
                resultadoLocal.pop_back();
            }
        }

        for (vector<vector<int>>::iterator it = todos_resultados.begin(); it != todos_resultados.end();) //Borra los caminos no satisfacibles
        {
            if (!satisfacible((*it)))
                todos_resultados.erase(it);
            else
                ++it;
        }

        
        while(!todos_resultados.empty()) 
        {
            resultadoLocal.clear();
            resultadoLocal = todos_resultados.front();
            todos_resultados.erase(todos_resultados.begin());

            vector<int> hijo = backTracking(resultadoLocal);
            if( !hijo.empty() && resultadoParcial.size() == dimension * 2)
            {
                double dist_hijo = this->calcularDistancia(hijo);
                if(dist_hijo <= distancia)
                    distancia = dist_hijo;
            }

        }

        return result;
    }
}

istream & operator>>(istream &is, SistemaMercancias &sist) {
    string linea, aux;

    getline(is, linea);

    size_t posDimension = linea.find("=");
    posDimension++;
    aux = linea.substr(posDimension);
    sist.dimension = stoi(aux);

    sist.puntos_venta = vector<int>(sist.dimension);
    sist.puntos_distribucion = vector<int>(sist.dimension);
    sist.nodos = vector<Nodo>(sist.dimension*2);

    for(unsigned int i=0; i < sist.dimension * 2; i++) {
        Nodo idAux;
        is >> idAux;
        sist.nodos[i] = idAux;

        if (i < sist.dimension)
            sist.puntos_venta.push_back(i+1);
        else
            sist.puntos_distribucion.push_back(i+1);
    }

    return is;
}
