#ifndef _CAMINO_HPP
#define _CAMINO_HPP

#include <iostream>
#include <vector>
#include <list>
#include <cmath>
#include <utility>
#include <map>
#include <stack>
#include <queue>

using namespace std;

class Camino{
    private:
        vector<int> recorrido;
        vector<vector<double>> matrizAdyacencia;
        double estimacion;

    public:
        Camino(vector<int> recorrido, vector<vector<double>> matriz);
        Camino();

        bool satisfacible() const;
        
        void push_back(int nuevo);

        void clear();
        const int & operator[](int id) const;
        int & operator[](int id);
        Camino& operator=(Camino b);
        void calcularEstimacion();

        double getEstimacion() { return estimacion; };
        vector<int> getRecorrido() {return recorrido; };
        size_t size() { return recorrido.size(); }; 

        bool es_nulo() { return recorrido.size() == 0; };
};

#endif