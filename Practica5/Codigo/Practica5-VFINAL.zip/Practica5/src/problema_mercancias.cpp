#include <vector>
#include <fstream>
#include <iostream>
#include "sistema_mercancias.hpp"

void mostrarVector(const vector<int> &v, SistemaMercancias sm , string ficheroEntrada){

    size_t principio_frase = ficheroEntrada.find_last_of("/");
    size_t final_frase = ficheroEntrada.find_last_of(".");

    size_t tam_frase = final_frase - principio_frase;

    string ficheroSalida = ficheroEntrada.substr(principio_frase+1, tam_frase-1);
    ficheroSalida += "_Backtracking.ciudades";
    
    ofstream salida("./data/" + ficheroSalida);

    salida << "SOLUCIÓN DE CAMINO MINIMO:\n";
    salida << "DIMENSION: " << sm.getDimension() << "\n";
    salida << "DISTANCIA: " << sm.getDistancia() << "\n"; 

    for (size_t i = 0; i<v.size() ; i++)
    {
        salida << sm.getNodo( (v[i]-1) ) <<"\n";   
    }
         
    salida.close();
};


int main( int argc, char **argv){
    if (argc != 2)
    {
        cout<<"Escriba el nombre del fichero a leer \n";
        exit(-1);
    }

    string filename = argv[1];
    ifstream fichero;
    fichero.open(filename);

    SistemaMercancias sm;
    fichero >> sm;

    vector<int> v, result;
    result = sm.backTracking(v);

    mostrarVector(result, sm, filename);

    fichero.close();
     
    return(0);
}